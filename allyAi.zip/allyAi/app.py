import os
import google.generativeai as genai
from flask import Flask, request, jsonify
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from flask_cors import CORS
import logging
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import smtplib
from email.message import EmailMessage
import requests  
from rake_nltk import Rake  # Import RAKE
import nltk
nltk.download('stopwords')
nltk.download('punkt_tab')


# Configure GenAI API
genai.configure(api_key="AIzaSyCouJFp2wH1_N8mqxh7Oiyl8dSULM03BPk")

app = Flask(__name__)
CORS(app)  # This will enable CORS for all routes
limiter = Limiter(get_remote_address, app=app)

generation_config = {
    "temperature": 1,
    "top_p": 0.95,
    "top_k": 40,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}

model = genai.GenerativeModel(
    model_name="gemini-1.5-flash",
    generation_config=generation_config,
)

# Mock influencer database (in a real case, this could be fetched dynamically)
mock_influencers = [
    {"name": "Influencer A", "cause": "women rights", "contact": "contactA@social.com"},
    {"name": "Influencer B", "cause": "mental health", "contact": "contactB@social.com"},
    {"name": "Influencer C", "cause": "gender violence", "contact": "contactC@social.com"},
]

# Google Custom Search API setup
API_KEY = "AIzaSyC6VsjXOxke69nuMrYNucUo7iOGu_Yd8hc"
CX = "64c2c4b821d764216"

@app.route("/submit_story", methods=["POST"])
def submit_story():
    data = request.json
    story = data.get("story")
    contact = data.get("contact")

    if not story or not contact:
        return jsonify({"error": "Story and contact are required."}), 400

    # Step 1: Summarize the story using Gemini AI
    summary = summarize_story_gemini(story)

    # Step 2: Search for matching influencers
    matching_influencers = search_influencers(summary)

    # Step 3: Send the story to influencers and return response
    influencer_contacts = []
    for influencer in matching_influencers:
        send_to_influencer(influencer["contact"], summary, contact)
        influencer_contacts.append(influencer["contact"])

    # Step 4: Return a response to the user
    return jsonify({
        "message": "Your story has been shared with relevant influencers. Thank you for speaking out.",
        "influencers_contacted": influencer_contacts
    })

def summarize_story_gemini(story):
    try:
        # Start a chat session for summarization
        chat_session = model.start_chat(history=[])
        response = chat_session.send_message(f"Summarize the following story: {story}")
        return response.text
    except Exception as e:
        print(f"Error in summarization: {e}")
        return "Error in summarization."

# Function to extract keywords from the summary using RAKE (Rake-NLTK)
def extract_keywords_rake(summary):
    try:
        # Initialize RAKE
        r = Rake()

        # Extract keywords from the summary
        r.extract_keywords_from_text(summary)
        keywords = r.get_ranked_phrases()  # Get key phrases sorted by rank
        
        if not keywords:
            print("No keywords extracted by RAKE. Trying fallback extraction.")
            keywords = manual_keyword_extraction(summary)
        
        return keywords
    except Exception as e:
        print(f"Error in keyword extraction: {e}")
        return []

# Fallback manual keyword extraction (can be enhanced)
def manual_keyword_extraction(summary):
    # Simple fallback for keywords extraction
    words = summary.split()
    return " ".join([word for word in words if len(word) > 3])  # Simple word length filter

# Function to search for influencers using Google Custom Search API
def search_influencers(summary):
    keywords = extract_keywords_rake(summary)  # Use RAKE for keyword extraction
    if not keywords:
        print("No keywords found for search.")
        return []

    search_url = f"https://www.googleapis.com/customsearch/v1?q={'+'.join(keywords)}&key={API_KEY}&cx={CX}"
    
    response = requests.get(search_url)
    
    if response.status_code == 200:
        search_results = response.json()
        influencers = []
        
        # Parse the search results to find influencer-related pages
        for item in search_results.get("items", []):
            title = item.get("title", "")
            link = item.get("link", "")
            snippet = item.get("snippet", "")
            
            # You can refine this by looking for social media or influencer-related pages
            if "influencer" in title.lower() or "profile" in title.lower():
                influencers.append({
                    "name": title,
                    "url": link,
                    "description": snippet
                })

        # Match extracted keywords with mock influencer database causes
        matching_influencers = []
        for influencer in influencers:
            for mock_influencer in mock_influencers:
                if mock_influencer["cause"].lower() in ' '.join(keywords).lower():
                    matching_influencers.append(mock_influencer)
        
        return matching_influencers
    else:
        print("Error with search API:", response.status_code)
        return []

# Function to send the story to influencers via email
def send_to_influencer(email, story_summary, user_contact):
    # Set up email content
    msg = EmailMessage()
    msg.set_content(f"Summary of Story: {story_summary}\nUser Contact: {user_contact}")
    msg["Subject"] = "A New Story Needs Your Voice"
    msg["From"] = "your_email@example.com"
    msg["To"] = email

    # Send email
    try:
        with smtplib.SMTP("smtp.example.com", 587) as server:
            server.starttls()
            server.login("your_email@example.com", "your_password")
            server.send_message(msg)
        print(f"Story sent to {email}")
    except Exception as e:
        print(f"Error sending email: {e}")



@app.route('/gender-equality-advice', methods=['POST'])
def gender_equality_advice():
  data = request.json
  question = data.get("question", "")

  # Check if question contains keywords related to gender equality
  keywords = ["gender equality", "gender equity", "women's rights", "feminism", "gender roles", "sexism"]
  if any(keyword in question.lower() for keyword in keywords):
    chat_session = genai.GenerativeModel(
      model_name="gemini-1.5-flash",
      generation_config={
        "temperature": 0.7,
        "top_p": 0.95,
        "top_k": 40,
        "max_output_tokens": 150
      }
    ).start_chat()

    # Send the question to Gemini AI and get the response
    response = chat_session.send_message(question)
    response_text = response.text.strip() if response else "I'm here to help with gender equality questions!"

    return jsonify({"reply": response_text})
  else:
    # Question doesn't seem related to gender equality
    return jsonify({"reply": "This question doesn't seem related to gender equality. Perhaps you can rephrase it or visit a general advice platform."})

if __name__ == '__main__':
    app.run(debug=True)
