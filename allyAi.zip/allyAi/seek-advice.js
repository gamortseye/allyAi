function displayMessage(text, className) {
    const chatBox = document.getElementById("chat-box");
    const messageDiv = document.createElement("div");
    messageDiv.className = className;
    messageDiv.textContent = text;
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight; // Scroll to the bottom
}

function sendMessage() {
    const userInput = document.getElementById("user-input");
    const message = userInput.value.trim();
    if (message === "") return;

    displayMessage(message, "user-message");
    userInput.value = ""; // Clear input

    // Send message to the backend
    fetch("http://127.0.0.1:5000/gender-equality-advice", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ question: message })
    })
    .then(response => response.json())
    .then(data => {
        displayMessage(data.reply, "bot-message");
    })
    .catch(error => {
        console.error("Error:", error);
        displayMessage("Sorry, something went wrong. Please try again.", "bot-message");
    });
}
