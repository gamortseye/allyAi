document.addEventListener("DOMContentLoaded", () => {
    fetchUserIP();
  
    const inputBox = document.getElementById("user-input");
  
    inputBox.addEventListener("input", adjustInputHeight);
    inputBox.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        sendMessage();
        e.preventDefault(); // Prevent newline on Enter
      }
    });
  });
  
  let storyContent = ""; // Store the accumulated story content
  
  function adjustInputHeight(event) {
    const inputBox = event.target;
    inputBox.style.height = "auto";
    inputBox.style.height = inputBox.scrollHeight + "px";
  }
  
  function fetchUserIP() {
    document.getElementById("user-ip").textContent = "Your IP: 123.456.789.000"; // Replace with actual fetch in production
  }
  
  function sendMessage() {
    const inputBox = document.getElementById("user-input");
    const userMessage = inputBox.value.trim();
    if (userMessage === "") return;
  
    displayMessage(userMessage, "user-message");
    storyContent += userMessage + " "; // Accumulate the story content
    console.log("Accumulated Story Content:", storyContent); // Debugging line
    inputBox.value = "";
    inputBox.style.height = "auto";
  
    handleChatLogic(userMessage);
  }
  
  function displayMessage(message, className) {
    const chatBox = document.getElementById("chat-box");
    const messageElement = document.createElement("div");
    messageElement.className = className;
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
  }
  
  function handleChatLogic(userMessage) {
    if (userMessage.toLowerCase() === "done") {
      displayMessage("Thank you! Could you please provide your public contact details and email?", "bot-message");
    } else if (userMessage.toLowerCase().includes("story")) {
      displayMessage("Got it! If you're finished with your story, please type 'done'.", "bot-message");
    } else if (validateEmail(userMessage)) {
      displayMessage("Thank you for providing your contact details. Searching for an influencer now...", "bot-message");
      showLoadingScreen();
      sendStoryToServer(userContact);
    } else {
      displayMessage("Please share your story or type 'done' if you are finished.", "bot-message");
    }
  }
  
  function validateEmail(email) {
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    return emailPattern.test(email);
  }
  
  function showLoadingScreen() {
    const chatBox = document.getElementById("chat-box");
    const loadingElement = document.createElement("div");
    loadingElement.className = "loading-screen";
    loadingElement.innerHTML = `
      <div class="loading-dots">
        <span>.</span><span>.</span><span>.</span>
      </div>
      <p>Searching for influencers...</p>
    `;
    chatBox.appendChild(loadingElement);
    chatBox.scrollTop = chatBox.scrollHeight;
  }
  
  function removeLoadingScreen() {
    const loadingElement = document.querySelector(".loading-screen");
    if (loadingElement) {
      loadingElement.remove();
    }
  }
  
  function sendStoryToServer(userContact) {
    // Anonymize data (replace with actual hashing implementation)
    const anonymizedStory = hashFunction(storyContent.trim());
  
    const user_details = { identifier: generateRandomID(), contact: userContact }; // Generate random identifier
  
    console.log("Data Sent to Backend (Anonymized):", { story: anonymizedStory, user_details }); // Debugging line
  
    // Display the confirmation message
    const confirmationMessage = `Here's a simplified version of your story (anonymized for demonstration). 
    Do you want to proceed with sending this story and your contact details (used for demonstration only) to simulate connecting with resources?`;
  
    if (confirm(confirmationMessage)) {
      showLoadingScreen(); // Show loading screen before sending
  
      // Mock backend response (replace with actual functionality for a real backend)
      fetch("http://127.0.0.1:5000/classify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ story: anonymizedStory, user_details })
      })
      .then(response => response.json())
      .then(data => {
        removeLoadingScreen(); // Remove loading screen on success
        displayMessage("Thank you for sharing your story. Resources will be sent to your contact (simulated).", "bot-message");
      })
      .catch(error => {
        console.error("Error:", error); // Debugging line
        removeLoadingScreen(); // Remove loading screen on error
        displayMessage("Sorry, something went wrong.", "bot-message");
      });
    } else {
      console.log("User cancelled sending data.");
      removeLoadingScreen(); // Remove loading screen if user cancels
      displayMessage("Data sending cancelled.", "bot-message");
    }
  }